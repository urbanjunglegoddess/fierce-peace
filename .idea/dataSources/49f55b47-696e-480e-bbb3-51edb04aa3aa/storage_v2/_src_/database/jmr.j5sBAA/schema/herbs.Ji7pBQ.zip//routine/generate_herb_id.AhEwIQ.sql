create function generate_herb_id() returns text
    language plpgsql
as
$$
DECLARE
    randomized_id TEXT;
    new_herb_id TEXT;
BEGIN
    LOOP
        randomized_id := generate_randomized_id();
        new_herb_id := CONCAT('HERB-', randomized_id);
        EXIT WHEN NOT EXISTS (SELECT 1 FROM herbs_info WHERE id = new_herb_id);
    END LOOP;
    RETURN new_herb_id;
END;
$$;

alter function generate_herb_id() owner to homebase;

