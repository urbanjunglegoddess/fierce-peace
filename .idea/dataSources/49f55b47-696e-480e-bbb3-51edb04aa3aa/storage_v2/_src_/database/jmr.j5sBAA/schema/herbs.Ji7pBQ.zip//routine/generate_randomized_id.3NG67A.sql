create function generate_randomized_id() returns text
    language plpgsql
as
$$
DECLARE
    random_number NUMERIC(3);
BEGIN
    random_number := FLOOR(RANDOM() * 900) + 100; -- Generate a random number between 100 and 999
    RETURN LPAD(random_number::TEXT, 3, '0'); -- Convert to text and pad with leading zeros
END;
$$;

alter function generate_randomized_id() owner to homebase;

