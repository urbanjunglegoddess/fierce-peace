create function xpath(text, xml) returns xml[]
    immutable
    strict
    parallel safe
    cost 1
    language sql
RETURN xpath($1, $2, '{}'::text[]);

comment on function xpath(text, xml) is 'evaluate XPath expression';

alter function xpath(text, xml) owner to postgres;

